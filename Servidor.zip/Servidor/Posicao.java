class Posicao  {
    int x;
    int y;
  
    Posicao(int x, int y) {
      this.x = x;
      this.y = y;
    }
  }