public class Visivel {
    boolean visivel;

    Visivel (boolean visivel) {
        this.visivel = visivel;
    }
}