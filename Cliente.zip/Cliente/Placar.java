public class Placar {
    int ptosA = 0;
    int ptosB = 0;
    int vidasA = 3;
    int vidasB = 3;
   
    public Placar(int pA, int pB, int vA, int vB) {
      ptosA = pA;
      ptosB = pB;
      vidasA = vA;
      vidasB = vB;
    }
  }